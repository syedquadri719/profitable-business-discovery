# profitable-business-discovery

MVP for a Profitable Business Discovery Tool using FastAPI.