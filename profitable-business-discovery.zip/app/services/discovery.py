def get_ideas():
    # Sample hardcoded data (replace with real logic later)
    return [
        {"title": "AI Video Script Generator", "trend_score": 88, "sentiment": 0.72},
        {"title": "Ghost Kitchen for Vegan Desserts", "trend_score": 79, "sentiment": 0.65}
    ]
